package mx.edu.ittepic.tam_servicioweb_vmz;

public interface AsyncResponse {
    void procesarRespuesta(String r);
}