package mx.edu.ittepic.unidad3_31jsonclima;

public interface AsyncResponse {
    void procesarRespuesta(String r);
}