package mx.edu.ittepic.tam_laboratorio_0_vicentemartinezzavala;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b0,b1,b2,b3,b4,b5,b6,b7,b8;
    int contador=0;
    TextView fin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b0=findViewById(R.id.button10);
        b1=findViewById(R.id.button11);
        b2=findViewById(R.id.button12);
        b3=findViewById(R.id.button13);
        b4=findViewById(R.id.button14);
        b5=findViewById(R.id.button15);
        b6=findViewById(R.id.button16);
        b7=findViewById(R.id.button17);
        b8=findViewById(R.id.button18);
        fin=findViewById(R.id.textView);
    b0.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(b0.getText().toString().length() == 0) {

                if (contador == 0 || contador == 2 || contador == 4 || contador == 6 || contador == 8) {
                    b0.setText("x");
                } else {
                    b0.setText("o");
                }

                contador++;
                if (contador == 9) {
                    Toast.makeText(MainActivity.this,"Fin del Juego",Toast.LENGTH_LONG).show();
                    b0.setText("");
                    b1.setText("");
                    b2.setText("");
                    b3.setText("");
                    b4.setText("");
                    b5.setText("");
                    b6.setText("");
                    b7.setText("");
                    b8.setText("");
                    contador=0;
                }
            }

        }
    });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b1.getText().toString().length() == 0) {
                    if (contador == 0 || contador == 2 || contador == 4 || contador == 6 || contador == 8) {
                        b1.setText("x");
                    } else {
                        b1.setText("o");
                    }
                    contador++;
                    if (contador == 9) {
                        Toast.makeText(MainActivity.this,"Fin del Juego",Toast.LENGTH_LONG).show();
                        b0.setText("");
                        b1.setText("");
                        b2.setText("");
                        b3.setText("");
                        b4.setText("");
                        b5.setText("");
                        b6.setText("");
                        b7.setText("");
                        b8.setText("");
                        contador=0;
                    }
                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b2.getText().toString().length() == 0) {
                    if (contador == 0 || contador == 2 || contador == 4 || contador == 6 || contador == 8) {
                        b2.setText("x");
                    } else {
                        b2.setText("o");
                    }
                    contador++;
                    if (contador == 9) {
                        Toast.makeText(MainActivity.this,"Fin del Juego",Toast.LENGTH_LONG).show();
                        b0.setText("");
                        b1.setText("");
                        b2.setText("");
                        b3.setText("");
                        b4.setText("");
                        b5.setText("");
                        b6.setText("");
                        b7.setText("");
                        b8.setText("");
                        contador=0;
                    }
                }
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b3.getText().toString().length() == 0) {
                    if (contador == 0 || contador == 2 || contador == 4 || contador == 6 || contador == 8) {
                        b3.setText("x");
                    } else {
                        b3.setText("o");
                    }
                    contador++;
                    if (contador == 9) {
                        Toast.makeText(MainActivity.this,"Fin del Juego",Toast.LENGTH_LONG).show();
                        b0.setText("");
                        b1.setText("");
                        b2.setText("");
                        b3.setText("");
                        b4.setText("");
                        b5.setText("");
                        b6.setText("");
                        b7.setText("");
                        b8.setText("");
                        contador=0;
                    }
                }
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b4.getText().toString().length() == 0) {
                    if (contador == 0 || contador == 2 || contador == 4 || contador == 6 || contador == 8) {
                        b4.setText("x");
                    } else {
                        b4.setText("o");
                    }
                    contador++;
                    if (contador == 9) {
                        Toast.makeText(MainActivity.this,"Fin del Juego",Toast.LENGTH_LONG).show();
                        b0.setText("");
                        b1.setText("");
                        b2.setText("");
                        b3.setText("");
                        b4.setText("");
                        b5.setText("");
                        b6.setText("");
                        b7.setText("");
                        b8.setText("");
                        contador=0;
                    }
                }
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b5.getText().toString().length() == 0) {
                    if (contador == 0 || contador == 2 || contador == 4 || contador == 6 || contador == 8) {
                        b5.setText("x");
                    } else {
                        b5.setText("o");
                    }
                    contador++;
                    if (contador == 9) {
                        Toast.makeText(MainActivity.this,"Fin del Juego",Toast.LENGTH_LONG).show();
                        b0.setText("");
                        b1.setText("");
                        b2.setText("");
                        b3.setText("");
                        b4.setText("");
                        b5.setText("");
                        b6.setText("");
                        b7.setText("");
                        b8.setText("");
                        contador=0;
                    }
                }
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b6.getText().toString().length() == 0) {
                    if (contador == 0 || contador == 2 || contador == 4 || contador == 6 || contador == 8) {
                        b6.setText("x");
                    } else {
                        b6.setText("o");
                    }
                    contador++;
                    if (contador == 9) {
                        Toast.makeText(MainActivity.this,"Fin del Juego",Toast.LENGTH_LONG).show();
                        b0.setText("");
                        b1.setText("");
                        b2.setText("");
                        b3.setText("");
                        b4.setText("");
                        b5.setText("");
                        b6.setText("");
                        b7.setText("");
                        b8.setText("");
                        contador=0;
                    }
                }
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b7.getText().toString().length() == 0) {
                    if (contador == 0 || contador == 2 || contador == 4 || contador == 6 || contador == 8) {
                        b7.setText("x");
                    } else {
                        b7.setText("o");
                    }
                    contador++;
                    if (contador == 9) {
                        Toast.makeText(MainActivity.this,"Fin del Juego",Toast.LENGTH_LONG).show();
                        b0.setText("");
                        b1.setText("");
                        b2.setText("");
                        b3.setText("");
                        b4.setText("");
                        b5.setText("");
                        b6.setText("");
                        b7.setText("");
                        b8.setText("");
                        contador=0;
                    }
                }
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(b8.getText().toString().length() == 0) {
                    if (contador == 0 || contador == 2 || contador == 4 || contador == 6 || contador == 8) {
                        b8.setText("x");
                    } else {
                        b8.setText("o");
                    }
                    contador++;
                    if (contador == 9) {
                        Toast.makeText(MainActivity.this,"Fin del Juego",Toast.LENGTH_LONG).show();
                        b0.setText("");
                        b1.setText("");
                        b2.setText("");
                        b3.setText("");
                        b4.setText("");
                        b5.setText("");
                        b6.setText("");
                        b7.setText("");
                        b8.setText("");
                        contador=0;
                    }
                }
            }
        });

    }
}
