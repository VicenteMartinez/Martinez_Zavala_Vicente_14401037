package mx.edu.ittepic.tam_laboratorio_1_vicentemartinezzavala;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edt;
    TextView res;
    Button bt1;
    int x;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt=findViewById(R.id.editText);
        res=findViewById(R.id.textView3);
        bt1=findViewById(R.id.button);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edt.getText().toString().length() == 0){
                    Toast.makeText(MainActivity.this,"No ha ingresado un numero",Toast.LENGTH_LONG).show();

                }else{

                    String numero1 = edt.getText().toString();
                    int numero2 = Integer.parseInt(numero1);
                    String result2 = "";
                    for(int i = 1; i <= 10; i++){
                        int result1 = i * numero2;
                        result2 += i+ " x " + numero1 + " = " + String.valueOf(result1) + '\n';
                    }
                    res.setText(result2);

                }
            }
        });

    }
}
